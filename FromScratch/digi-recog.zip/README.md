Fifth commit

Trains the network by adjusting weights and biases in order to produce output.
Applied new algorithm that adjusts the weights and biases taking into account all training samples
The network is almost perfect when it has structure of X:5:10:Y where X and Y are determined by the data
